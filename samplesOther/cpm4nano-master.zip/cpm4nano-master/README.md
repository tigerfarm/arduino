<i>cpm4nano</i> - эмулятор i8080-компьютера под управлением CP/M на Arduino Nano.<br/>
Версия 1<br/><br/>
Copyright (C) 2017 Алексей "FoxyLab" Воронин<br/>
Электронная почта:    support@foxylab.com<br/>
Сайт:  https://acdc.foxylab.com<br/>
Это программное обеспечение распространяется под лицензией GPL v3.0.<br/><br/>
Подробное описание эмулятора - https://acdc.foxylab.com/node/76<br/><br/><br/>
<i>cpm4nano</i> - i8080 & CP/M emulator for Arduino Nano.<br/>
Version 1<br/><br/>
Copyright (C) 2017 Alexey "FoxyLab" Voronin<br/>
Email:    support@foxylab.com<br/>
Website:  https://acdc.foxylab.com<br/>
This software is licensed under the GPL v3.0 License.<br/><br/>
Detailed description (in russian) - https://acdc.foxylab.com/node/76.
